<?php
	global $smarty;
	require_once(dirname(__FILE__).'/config.php');	
	require_once('core.php');
?>