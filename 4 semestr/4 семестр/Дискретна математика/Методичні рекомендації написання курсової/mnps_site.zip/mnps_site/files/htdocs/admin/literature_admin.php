<?php
global $smarty,$database;
require_once(dirname(dirname(__FILE__)).'/config.php');

if(isset($_SESSION['lang'])) {
	require_once(BASE_DIR.'includes/'.$_SESSION['lang'].'.lang.php');		
}
else {
	require_once(BASE_DIR.'includes/ua.lang.php');		
}

if(!isset($_SESSION['user'])) {
	$smarty->assign('admin_errMessage',ADMINP_ACCDENY_MSG);
	$smarty->display('admin.tpl');
	exit;
}

if(isset($_GET['lit_action']) && $_GET['lit_action'] == "delete" && isset($_GET['id']) && is_numeric($_GET['id'])) {	
	
	$query="select * from literatures where id='".$_GET['id']."' limit 1";	
	$result=$database->query($query);
	if($result) {
		$row=$database->fetch($result);
		if(!empty($row['filepath'])) {
			$file_name='files/books/'.$row['filepath'];
			if(file_exists($file_name)) {
				unlink($file_name);
			}
		}
	}
	else {
		$smarty->assign('lit_errMessage',LIT_NOTDEL_MSG);
		$smarty->display('literature.tpl');
		exit;
	}
	
	$query="delete from literatures where id='".$_GET['id']."' limit 1";	
	$result=$database->query($query);
	if(!$result) {
		$smarty->assign('lit_errMessage',LIT_NOTDEL_MSG);
		$smarty->display('literature.tpl');
		exit;
	}
	require_once('literature.php');
}

if(isset($_GET['lit_action']) && $_GET['lit_action'] == "add") {
	$smarty->display('literature_add.tpl');
}


if(isset($_POST['go_addlit'])) {
	$liter_content['name']=$_POST['name'];
	$liter_content['author']=$_POST['author'];
	
	$err_msg='';
	$error_flag=false;
	$up_error_flag=false;
	
	//Validate of fields
	if(!preg_match('/.{1,255}/', trim($_POST['name']))) {
		$err_msg=LIT_ERR_NAME;
		$error_flag=true;
		$form_content['name']='';
	}
	if(!preg_match('/.{1,255}/', trim($_POST['author']))) {
		$err_msg.=LIT_ERR_AUTHOR;
		$error_flag=true;
		$form_content['author']='';
	}
	
	if($error_flag) {
		$smarty->assign('lit_errMessage', $err_msg.'<br>');
		$smarty->assign('liter_content', $liter_content);		
		$smarty->display('literature_add.tpl');
		exit;
	}
	
	//Check and upload file	
	$uploaddir = BASE_DIR.'files/books/';
	$uploadfile = $uploaddir.rand(1,9999).'_'.basename($_FILES['filename']['name']);	
		
	if(!empty($_FILES['filename']['tmp_name']) || ($_FILES['filename']['error']>0 && $_FILES['filename']['error']<4)) {
		if($_FILES['filename']['error']>0) {
			$err_msg.=ERR_FILELENGTH_MSG;
			$up_error_flag=true;		
		}
		elseif($_FILES['filename']['type']!='application/x-bzip2' &&
			$_FILES['filename']['type']!='application/x-gtar' &&
			$_FILES['filename']['type']!='application/x-gzip' &&
			$_FILES['filename']['type']!='application/x-tar' &&
			$_FILES['filename']['type']!='application/zip' &&
			$_FILES['filename']['type']!='application/rar' &&
			$_FILES['filename']['type']!='application/x-zip-compressed' &&
			$_FILES['filename']['type']!='application/octet-stream'){
				$err_msg.=ERR_FILEFORMAT_MSG;
				$up_error_flag=true;		
		}
		elseif($_FILES['filename']['size']>MAX_FILE_SIZE) {
			$err_msg.=ERR_FILESIZE_MSG.MAX_FILE_SIZE.'<br>';
			$up_error_flag=true;
		}
		else {
			if (!move_uploaded_file($_FILES['filename']['tmp_name'], $uploadfile)) {
				$err_msg.=ERR_FILEATTACK_MSG;
				$up_error_flag=true;
			}
			else {
				$path_to_file=basename($uploadfile);				
			}
		}
	}
	else {
		$path_to_file='';		
	}	
	if($up_error_flag) {	
		$smarty->assign('lit_errMessage', $err_msg.'<br>');
		$smarty->assign('liter_content', $liter_content);		
		$smarty->display('literature_add.tpl');
		exit;
	}
	
	$query="insert into literatures values('','".strip_tags(addslashes(trim($_POST['author'])))."','".strip_tags(addslashes(trim($_POST['name'])))."','".addslashes($path_to_file)."')";		
	$result=$database->query($query);
	if(!$result) {
		$smarty->assign('lit_errMessage', ERR_DBINSERT_MSG);
		$smarty->assign('liter_content', $liter_content);		
		$smarty->display('literature_add.tpl');
		exit;
	}
	$smarty->assign('ok_message', SUCCES_DBINSERT_MSG);
	$smarty->display('success.tpl');
	exit;
}
?>