<?php /* Smarty version 2.6.18, created on 2007-12-12 22:37:28
         compiled from success.tpl */ ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php 
	global $smarty;	
	if(isset($_SESSION['lang'])) {
		require_once('includes/'.$_SESSION['lang'].'.lang.php');		
	}
	else {
		require_once('includes/ua.lang.php');		
	}	
 ?>

<img src="images/1.gif" width=2 height=50>
<span class="contentText"><?php echo SPAN_PAGETITLE_MSG ?></span><br>
<img src="images/1.gif"  width=2 height=30>
<table width="90%" cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td class="content" align="center">
			<h4 align="center"><?php echo $this->_tpl_vars['ok_message']; ?>
</h4><br>
		</td>
	</tr>
</table>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>