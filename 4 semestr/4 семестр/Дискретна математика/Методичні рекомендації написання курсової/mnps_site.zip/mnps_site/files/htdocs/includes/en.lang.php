<?php
	/*******header.tpl*******/
	
	define('SPAN_PROJECTNAME_MSG','Project MNPS');
	define('SPAN_PROJECTLOGO_MSG','INTERUNIVERSITY SCIENTIFIC-PRACTICAL SEMINAR');
	define('HORMENU_HOME_MSG','Home');
	define('HORMENU_ORGCOM_MSG','Organizing committee');
	define('HORMENU_REGLAMENT_MSG','Reglament');
	define('HORMENU_VIEWTHEMS_MSG','Works viewing');
	define('HORMENU_ADDRECORD_MSG','Add new work');
	define('HORMENU_LITERATURE_MSG','Literature');
	define('ADMINMENU_ADMIN_MSG','Administrator');
	define('ADMINMENU_EDITHOME_MSG','Edit home');
	define('ADMINMENU_EDITORGCOM_MSG','Edit orgcomittee');
	define('ADMINMENU_REGLAMENT_MSG','Edit reglament');
	define('ADMINMENU_FORADMIN_MSG','For admin');
	define('ADMINMENU_LITERATURE_MSG','Add a book');
	define('POPUP_ORGCOM_MSG','Viewing orgcomittee members');
	define('POPUP_REGLAMENT_MSG','Acquaintance with the rules of work of a seminar');
	define('POPUP_VIEWTHEMS_MSG','Show the general table of works');
	define('POPUP_ADDRECORD_MSG','Add new work');
	define('POPUP_FORADMIN_MSG','Only for using of site administrator!');
	define('CHOOSE_LANG_MSG','Choose the language');
	
	
	/*****addrecord.tpl******/
	
	define('SPAN_PAGETITLE_MSG','Adding new work');
	define('SPAN_FNAME_MSG','First name');
	define('SPAN_LNAME_MSG','Second name');
	define('SPAN_EXTINFO_MSG','Author additional info');
	define('SPAN_WORKNAME_MSG','Name of work');
	define('SPAN_WORKDESCRIPT_MSG','Brief description of work');
	define('SPAN_ADDFILE_MSG','Add a file');
	define('POPUP_REQUIRED_MSG','Obligatory field');
	define('POPUP_REQUIRED255_MSG','Obligatory field, no more 255 symbols!');
	
		
	/*****addrecord.php******/
	define('ERR_WRONGFNAME_MSG','Entered wrong name<br>');
	define('ERR_WRONGLNAME_MSG','Entered wrong last name<br>');
	define('ERR_WRONGEMAIL_MSG','Entered wrong e-mail address<br>');
	define('ERR_WRONGLENGTH255_MSG','more than 255 characters are entered<br>');
	define('ERR_WRONGTHEM_MSG','Entered wrong theme<br>');
	define('ERR_WRONGDESCRIPTION_MSG','Entered incorrect description<br>');
	define('ERR_FILELENGTH_MSG','Error at the load of file, possibly size too
largeand<br>');
	define('ERR_FILEFORMAT_MSG','The loaded file must be an archive!<br>');	
	define('ERR_FILESIZE_MSG','The size of the loaded file must be smaller <br>');
	define('ERR_FILEATTACK_MSG','Invalid file upload, possible upload attack<br>');
	define('ERR_RECEXIST_MSG','A record with entered address already exists in database!<br>');
	define('ERR_DBINSERT_MSG','Invalid inserting data to DB!<br>');
	define('SUCCES_DBINSERT_MSG','Information is successfully added to the database');
	
	
	/*****viewlist.tpl******/
	
	define('AUTHOR_MSG','Author');
	define('WORKNAME_MSG','Name of work');
	define('ACTION_MSG','Action');
	define('DELETE_MSG','Delete');
	define('EDIT_MSG','Edit');
	
	
	/*****viewlist.php******/
	
	define('EDITING_THEMS_MSG','Viewing themes of seminars');
	define('ATTACK_GETPARAM_MSG','GET parameters attack!!');
	define('ERR_DBACCESS_MSG','Error access to DB!');
	define('ERR_DBEMPTY_MSG','Database is empty!!');
	
	
	/*****authorize.tpl******/
	
	define('AUTH_HEADER_MSG','Authorization');
	define('AUTH_LOGIN_MSG','Login');
	define('AUTH_PASSWORD_MSG','Password');
	
	/*****authorize.php******/
	
	define('AUTH_EMPTYLOGPASS_MSG','You must enter a login and password!');
	define('AUTH_ERRLOGPASS_MSG','Entered wrong login or password!');
	
	
	/*****home.php, reglament.php, orgcomitee.php, ******/
	
	define('HOME_EMPTYCONTENT_MSG','Empty contents of page');
	
	/*****detal_view.tpl******/
	
	define('DVIEW_THEM_MSG','Theme');
	define('DVIEW_PUBLICDATE_MSG','Date of publication');
	define('DVIEW_EMAIL_MSG','E-mail of author');
	define('DVIEW_AUTHORINFO_MSG','Information about an author');
	define('DVIEW_THEMDESCRIPT_MSG','Brief of the work');
	define('DVIEW_UPLOADFILE_MSG','Load an archive with materials');
	define('DVIEW_NOFILE_MSG','no file');
	define('DVIEW_BACK_MSG','Back to to the list');	
	
	
	/*****editcontent.tpl******/
	
	define('ECONT_HEADER_MSG','Heading');
	define('ECONT_PAGECONTENT_MSG','Contents of page');
	
	
	/*****admin.tpl******/
	
	define('ADMIN_AUTHORIZATION_MSG','Authorizing...');
	define('ADMIN_DEAR1_MSG','Dear');
	define('ADMIN_DEAR2_MSG','you were successfully authorized as administrator!');
	define('ADMIN_DEAR3_MSG','Do not forget please about safety of page, to nobody trust a password and do not abandon the opened type without examination.');
	
	
	/*****admin.php******/
	
	define('ADMINP_ACCDENY_MSG','You do not have a permission for viewing of this page!');
	define('ADMINP_HOMEEDITING_MSG','Main page: editing');
	define('ADMINP_ORGCOMEDITING_MSG','Organizing committee: editing');
	define('ADMINP_REGLAMENTEDITING_MSG','Regulation: editing');
	define('ADMINP_ERRGETPARAM_MSG','Error in parameters to the GET line!');
	define('ADMINP_ERRADDHEADER_MSG','Wrong heading is entered<br>');
	define('ADMINP_ERRADDBODY_MSG','A body is not correctly entered<br>');
	define('ADMINP_ERRDBUPDATE_MSG','Error updating record from DB!');
	define('ADMINP_ERRDBDELETE_MSG','Error deleting record from DB!<p/>');
	define('ADMINP_ERRDB_MSG','Error at the address to DB<br>');
	define('ADMINP_ATTENTION_MSG','ATTENTION! If the not chosen file for the load, old file will remove automatically!');
	
	
	/*****literature.php*****/
	
	define('LIT_ERR_EMPTYDB','Literature is empty');
	
	/*****literature.tpl*****/
	
	define('LIT_NAME_MSG','Book name');
	define('LIT_AUTHOR_MSG','Author');
	define('LIT_FILE_MSG','File for download');
	define('LIT_HEADER','Literature');
	define('LIT_DELETE_MSG','Delete');
	
	
	/*****literature_admin.tpl*****/
	
	define('LIT_NOTDEL_MSG','Book deleting error!<br/>');
	
	
	/*****literature_admin.php*****/
	
	define('LIT_ERR_NAME','Wrong name format of book<br/>');
	define('LIT_ERR_AUTHOR','Wrong author format of book<br/>');
	
	/*****literature_add.tpl*****/
	
	define('LIT_PAGETITLE_MSG','Adding a new Book');	
	define('LIT_ADDFILE_MSG','Join book file');
?>
	
	