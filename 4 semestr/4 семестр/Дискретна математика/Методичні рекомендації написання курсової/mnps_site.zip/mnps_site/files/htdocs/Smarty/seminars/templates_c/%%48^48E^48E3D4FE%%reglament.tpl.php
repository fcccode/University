<?php /* Smarty version 2.6.18, created on 2007-11-15 23:19:28
         compiled from reglament.tpl */ ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<img src="images/1.gif" width=2 height=50>
<span class="contentText"><?php echo $this->_tpl_vars['reglament_head']; ?>
</span><br>
<img src="images/1.gif"  width=2 height=30>
<table width="90%" cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td class="content" valign="top">
			<span class="textError" align="center"><?php echo $this->_tpl_vars['reglament_errMessage']; ?>
</span>			
			<?php echo $this->_tpl_vars['reglament_content']; ?>

		</td>
	</tr>
</table>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>