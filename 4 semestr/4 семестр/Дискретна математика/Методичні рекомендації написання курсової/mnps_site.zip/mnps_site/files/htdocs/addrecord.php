<?php
global $smarty,$database;
require_once(dirname(__FILE__).'/config.php');

if(isset($_SESSION['lang'])) {
	require_once(BASE_DIR.'includes/'.$_SESSION['lang'].'.lang.php');
}
else {
	require_once(BASE_DIR.'includes/ua.lang.php');		
}


if(isset($_POST['go_addrecord'])) {
	
	//Save old form content
	$form_content['first_name']=$_POST['first_name'];
	$form_content['last_name']=$_POST['last_name'];
	$form_content['email']=$_POST['email'];
	$form_content['info']=$_POST['info'];
	$form_content['them']=$_POST['them'];
	$comment=$_POST['comment'];
	
	$err_msg='';
	$error_flag=false;
	$up_error_flag=false;
	
	//Validate of fields
	if(!preg_match('/.{1,80}/', trim($_POST['first_name']))) {
		$err_msg=ERR_WRONGFNAME_MSG;
		$error_flag=true;
		$form_content['first_name']='';
	}
	if(!preg_match('/.{1,80}/', trim($_POST['last_name']))) {
		$err_msg.=ERR_WRONGLNAME_MSG;
		$error_flag=true;
		$form_content['last_name']='';
	}
	if(!eregi("^([0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-wyz][a-z](fo|g|l|m|mes|o|op|pa|ro|seum|t|u|v|z)?)$", trim($_POST['email']))) {
		$err_msg.=ERR_WRONGEMAIL_MSG;
		$error_flag=true;
		$form_content['email']='';
	}	
	if(!preg_match('/.{0,255}/', trim($_POST['info']))) {
		$err_msg.=ERR_WRONGLENGTH255_MSG;
		$error_flag=true;
		$form_content['info']='';
	}	
	if(!preg_match('/.{1,255}/', trim($_POST['them']))) {
		$err_msg.=ERR_WRONGTHEM_MSG;
		$error_flag=true;
		$form_content['them']='';
	}
	if(!preg_match('/.{1,65535}/', trim($_POST['comment']))) {
		$err_msg.=ERR_WRONGDESCRIPTION_MSG;
		$error_flag=true;
		$comment='';
	}
	
	if($error_flag) {
		$smarty->assign('add_errMessage', $err_msg.'<br>');
		$smarty->assign('form_content', $form_content);
		$smarty->assign('comment', $comment);
		$smarty->display('addrecord.tpl');
		exit;
	}
	
	
	//Check and upload file	
	$uploaddir = BASE_DIR.'files/';
	$uploadfile = $uploaddir.rand(1,9999).'_'.basename($_FILES['filename']['name']);	
		
	if(!empty($_FILES['filename']['tmp_name']) || ($_FILES['filename']['error']>0 && $_FILES['filename']['error']<4)) {
		if($_FILES['filename']['error']>0) {
			$err_msg.=ERR_FILELENGTH_MSG;
			$up_error_flag=true;		
		}
		elseif($_FILES['filename']['type']!='application/x-bzip2' &&
			$_FILES['filename']['type']!='application/x-gtar' &&
			$_FILES['filename']['type']!='application/x-gzip' &&
			$_FILES['filename']['type']!='application/x-tar' &&
			$_FILES['filename']['type']!='application/zip' &&
			$_FILES['filename']['type']!='application/rar' &&
			$_FILES['filename']['type']!='application/x-zip-compressed' &&
			$_FILES['filename']['type']!='application/octet-stream'){
				$err_msg.=ERR_FILEFORMAT_MSG;
				$up_error_flag=true;		
		}
		elseif($_FILES['filename']['size']>MAX_FILE_SIZE) {
			$err_msg.=ERR_FILESIZE_MSG.MAX_FILE_SIZE.'<br>';
			$up_error_flag=true;
		}
		else {
			if (!move_uploaded_file($_FILES['filename']['tmp_name'], $uploadfile)) {
				$err_msg.=ERR_FILEATTACK_MSG;
				$up_error_flag=true;
			}
			else {
				$path_to_file=basename($uploadfile);				
			}
		}
	}
	else {
		$path_to_file='';		
	}	
	if($up_error_flag) {	
		$smarty->assign('add_errMessage', $err_msg.'<br>');
		$smarty->assign('form_content', $form_content);
		$smarty->assign('comment', $comment);
		$smarty->display('addrecord.tpl');
		exit;
	}
	
	//here is inserting to database
	$query="select * from users where email='".strip_tags(addslashes(trim($_POST['email'])))."' and them='".strip_tags(addslashes(trim($_POST['them'])))."'";
	$result=$database->query($query);	
	if($result) {
		$count=$database->numRows($result);
		if($count>0) {
			$smarty->assign('add_errMessage', ERR_RECEXIST_MSG);
			$smarty->assign('form_content', $form_content);
			$smarty->assign('comment', $comment);
			$smarty->display('addrecord.tpl');
			exit;
		}
	}
	
	$query="insert into users values('','".strip_tags(addslashes(trim($_POST['first_name'])))."','".strip_tags(addslashes(trim($_POST['last_name'])))."','".strip_tags(addslashes(trim($_POST['email'])))."','".strip_tags(addslashes(trim($_POST['info'])))."','".strip_tags(addslashes(trim($_POST['them'])))."','".addslashes($_POST['comment'])."','".addslashes($path_to_file)."',NOW())";
	$result=$database->query($query);
	if(!$result) {
		$smarty->assign('add_errMessage', ERR_DBINSERT_MSG);
		$smarty->assign('form_content', $form_content);
		$smarty->assign('comment', $comment);
		$smarty->display('addrecord.tpl');
		exit;
	}
	$smarty->assign('ok_message', SUCCES_DBINSERT_MSG);
	$smarty->display('success.tpl');
	exit;	
}
else {
	$smarty->display('addrecord.tpl');
}
?>