<?php
global $smarty,$database;
require_once(dirname(__FILE__).'/config.php');

if(isset($_SESSION['lang'])) {
	require_once(BASE_DIR.'includes/'.$_SESSION['lang'].'.lang.php');
}
else {
	require_once(BASE_DIR.'includes/ua.lang.php');		
}

if(isset($_GET['logout']) && $_GET['logout']=='yes') {
	unset($_SESSION['user']);
	require_once('viewlist.php');
	exit;
}

if(isset($_SESSION['user'])) {
	//redirect
	require_once('admin/admin.php');
	exit;
}

if(isset($_POST['go_authorize'])) {
	if(empty($_POST['login']) || empty($_POST['password'])) {
		$smarty->assign('auth_errMessage',AUTH_EMPTYLOGPASS_MSG);
	}
	else {
		$query="select * from admin where login='".strip_tags(addslashes(trim($_POST['login'])))."' and password=MD5('".strip_tags(addslashes(trim($_POST['password'])))."') limit 1";		
		$result=$database->query($query);		
		if($result) {
			$count=$database->numRows($result);			
			if($count>0) {
				$row=$database->fetch($result);
				$_SESSION['user']['fname']=$row['fname'];
				$_SESSION['user']['lname']=$row['lname'];
				$_SESSION['user']['login']=$row['login'];
				
				require_once('admin/admin.php');
				exit;
			}
		}
		$smarty->assign('auth_errMessage',AUTH_ERRLOGPASS_MSG);		
	}
}
$smarty->display('authorize.tpl');
?>