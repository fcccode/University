<?php
define ("BASE_DIR", dirname(dirname(__FILE__)) .'/');
define ("SITE_NAME", 'http://localhost/seminars/');
define ("MAX_FILE_SIZE", 1000000);
define ("DEBUG", 1);
?>