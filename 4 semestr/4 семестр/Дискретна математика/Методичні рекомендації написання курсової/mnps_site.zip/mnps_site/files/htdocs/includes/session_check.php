<?php
	global $smarty;
	if(isset($_SESSION['user']))
	{		
		$smarty->assign('islogin',1);								
	}
	else
	{
		$smarty->assign('islogin',0);				
		
	}	
?>