<?php /* Smarty version 2.6.18, created on 2007-12-12 22:46:35
         compiled from editcontent.tpl */ ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php 
	global $smarty;	
	if(isset($_SESSION['lang'])) {
		require_once('includes/'.$_SESSION['lang'].'.lang.php');		
	}
	else {
		require_once('includes/ua.lang.php');		
	}	
 ?>

<img src="images/1.gif" width=2 height=50>
<span class="contentText"><?php echo $this->_tpl_vars['editcontent_head']; ?>
</span><br>
<img src="images/1.gif"  width=2 height=30>
<table width="90%" cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td class="content" valign="top">
			<span class="textError" align="center"><?php echo $this->_tpl_vars['editcontent_errMessage']; ?>
</span>			
			<?php if ($this->_tpl_vars['isError'] != 'true'): ?>
			<form name="editcontent" method="post" action="core.php?page=admin&edittype=none&editof=<?php echo $this->_tpl_vars['type']; ?>
">			
			<table border="0" width="100%">				
				<tr>
					<td>
						<br><span class="textCopy"><b><?php echo ECONT_HEADER_MSG ?>:</b></span><br>
						<textarea name="head_content" cols="60" rows="7" class="form-input-text" wrap="virtual"/>
							<?php echo $this->_tpl_vars['head']; ?>

						</textarea>						
					</td>
				</tr>				
				<tr>
					<td>
						<br><span class="textCopy"><b><?php echo ECONT_PAGECONTENT_MSG ?>:</b></span><br>
						<?php 
							global $smarty;
							include("includes/htmledit/fckeditor.php");
							$sBasePath = "includes/htmledit/";
							$oFCKeditor = new FCKeditor('body_content');
							$oFCKeditor->BasePath	= $sBasePath;
							$oFCKeditor->Value		= $smarty->get_template_vars('body');
							$oFCKeditor->Create();
						 ?>
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>				
				<tr>
					<td>
						<input type="submit" name="go_editcontent" value="OK" class="form-button"/>
					</td>
				</tr>
			</table>
			</form>
			<?php endif; ?>
		</td>
	</tr>
</table>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>