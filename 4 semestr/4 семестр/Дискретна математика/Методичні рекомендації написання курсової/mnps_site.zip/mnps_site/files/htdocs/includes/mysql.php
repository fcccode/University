<?php
//��� ���������� ���������� ������ � probesdb/////////////


class MySQL
{
	var $connection;
	var $query;

	function MySQL($host, $user, $password, $db, $port="3306")
	{
		$this->connection=mysql_pconnect($host,$user,$password);
		mysql_select_db($db,$this->connection);
	}

	function getLastID(){
	    return mysql_insert_id($this->connection);
	}

    function startTransaction()
    {
		$this->query=array();
		return true;
    }

    function commitTransaction()
    {
	   	mysql_query ("begin",$this->connection);

	   	foreach($this->query as $query)
	   	{
		   	$ret=mysql_query ($query,$this->connection);
			if (!$ret && DEBUG==1)
			{
				echo mysql_error();
			}

		   	if (!$ret)
		   		return false;
		   	
	   	}
	   	
	   	$ret = mysql_query ("commit",$this->connection);
        return $ret;
    }

    function query($query)
    {

		if (DEBUG==1) {
			$f=fopen(BASE_DIR."logs/mysql_q.log", "a");
			fwrite($f, date("Y-m-d H:i:s")."\n".$query."\n\n");
			fclose($f);
			@chmod(BASE_DIR."logs/mysql_q.log", 0666);
		}

        $ret = mysql_query($query, $this->connection);

		$err=mysql_error();

		if (DEBUG==1)
	        echo $err;

		if ($err){
			$f=fopen(BASE_DIR."logs/mysql_err.log", "a");
			fwrite($f, date("Y-m-d H:i:s")."\n".$query."\n".$err."\n-------------------------\n\n");
			fclose($f);
			@chmod(BASE_DIR."logs/mysql_q.log", 0666);
		}

    	return $ret;
    }

    function aquery($query)
    {
        $this->query[]=$query;
    	return true;
    }

    function fetch (&$what, $row=0)
    {
        if (mysql_num_rows($what)==0)
        	return false;
    	return mysql_fetch_array($what);
    }

    function fetchAll (&$what)
    {
        if (mysql_num_rows($what)==0) {
        	return false;
        }

        while($row=mysql_fetch_array($what))
        {
        	$ret[]=$row;
        }

    	return $ret;
    }

    function numRows(&$what)
    {
    	$result = mysql_num_rows($what);
        if ($result == 0 || $result == -1) return false;
        return $result;
    }
	function close(){
		return mysql_close($this->connection);
	}
}
?>