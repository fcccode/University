<?php /* Smarty version 2.6.18, created on 2007-12-12 22:03:23
         compiled from authorize.tpl */ ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php 
	global $smarty;	
	if(isset($_SESSION['lang'])) {
		require_once('includes/'.$_SESSION['lang'].'.lang.php');		
	}
	else {
		require_once('includes/ua.lang.php');		
	}	
 ?>

<img src="images/1.gif" width=2 height=50>
<span class="contentText"><?php echo AUTH_HEADER_MSG ?></span><br>
<img src="images/1.gif"  width=2 height=30>
<table width="90%" cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td class="content">
			<span class="textError" align="center"><?php echo $this->_tpl_vars['auth_errMessage']; ?>
</span><p/>
			<form name="authorize" method="post" action="core.php?page=authorize">
				<table border="0" align="center">
					<tr>
						<td>
							<span class="textCopy"><b><?php echo AUTH_LOGIN_MSG ?>:&nbsp;</b></span>
						</td>
						<td>
							<input type="text" name="login" maxlength="255" class="form-input-text"/>
						</td>					
					</tr>
					<tr>
						<td>
							<span class="textCopy"><b><?php echo AUTH_PASSWORD_MSG ?>:&nbsp;</b></span>
						</td>
						<td>
							<input type="password" name="password" maxlength="255" class="form-input-text"/>
						</td>	
					</tr>
					<tr>
						<td colspan="2" align="center">
							<input type="submit" name="go_authorize" value="OK" class="form-button"/>
						</td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
</table>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>