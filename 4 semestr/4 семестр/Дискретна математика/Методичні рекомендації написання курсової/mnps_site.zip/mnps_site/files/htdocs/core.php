<?php
global $smarty,$database;
require_once(dirname(__FILE__).'/config.php');


if(!isset($_GET["page"]))		
	//Here is start page including
	require_once('home.php');
else
{	
	if(isset($_SESSION['user']) && $_GET['page']==="logout")
	{			
		unset($_SESSION['user']);									
	}
	
	switch($_GET['page'])
	{
		case "addrec":													
			require_once('addrecord.php');
			//$smarty->display('addrecord.tpl');
			break;			
			
		case "authorize":
			require_once('authorize.php');
			break;
			
		case "admin":
			require_once('admin/admin.php');
			break;
			
		case "editrec":
			require_once('admin/edit.php');
			break;
			
		case "view":
			require_once('viewlist.php');
			break;
			
		case "orgcom":
			require_once('orgcomitee.php');
			break;
		
		case "reglament":
			require_once('reglament.php');
			break;
			
		case "langchoice":
			changeLanguage();
			require_once('home.php');
			break;
				
		case "literature":
			require_once('literature.php');
			break;
			
		case "literature_admin":
			require_once('admin/literature_admin.php');
			break;
		
		default:	
			//��������� �� �������� ������� ����� �������							
			require_once('home.php');
			break;
	}
}

function changeLanguage() {
	$languages=array("ua","en");
	if(isset($_GET['lang']) && in_array($_GET['lang'],$languages)) {
		require_once(BASE_DIR.'includes/'.$_GET['lang'].'.lang.php');
		$_SESSION['lang']=$_GET['lang'];
	}
	else {		
		require_once(BASE_DIR.'includes/ua.lang.php');
		$_SESSION['lang']="ua";
	}
}		
?>	