<?php /* Smarty version 2.6.18, created on 2007-12-28 10:14:19
         compiled from literature_add.tpl */ ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php require_once(SMARTY_CORE_DIR . 'core.smarty_include_php.php');
smarty_core_smarty_include_php(array('smarty_file' => "includes/session_check.php", 'smarty_assign' => '', 'smarty_once' => false, 'smarty_include_vars' => array()), $this); ?>


<?php 
	global $smarty;
	if(isset($_SESSION['lang'])) {
		require_once('includes/'.$_SESSION['lang'].'.lang.php');		
	}
	else {
		require_once('includes/ua.lang.php');
		
	}	
 ?>
<img src="images/1.gif" width=2 height=50>
<span class="contentText"><?php echo LIT_PAGETITLE_MSG ?></span><br>
<img src="images/1.gif"  width=2 height=30>
<table width="90%" cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td class="content">
			<span class="textError" align="center"><?php echo $this->_tpl_vars['lit_errMessage']; ?>
</span><br>
			<form name="addliterature" method="post" action="core.php?page=literature_admin&lit_action=submit" enctype="multipart/form-data">			
			<table border="0" width="100%">
				<tr>
					<td align="right">
						<span class="textCopy"><b><?php  echo LIT_NAME_MSG ?>:&nbsp;</b></span>
					</td>
					<td align="left">
						<textarea name="name" cols="40" rows="3" class="form-input-text" wrap="virtual"/>
							<?php echo $this->_tpl_vars['liter_content']['name']; ?>

						</textarea>	
					</td>					
				</tr>
				<tr>
					<td align="right">
						<span class="textCopy"><b><?php  echo LIT_AUTHOR_MSG ?>:&nbsp;</b></span>
					</td>
					<td align="left">
						<textarea name="author" cols="40" rows="3" class="form-input-text" wrap="virtual"/>
							<?php echo $this->_tpl_vars['liter_content']['author']; ?>

						</textarea>							
					</td>
				</tr>
				<tr>
					<td align="right">
						<span class="textCopy"><b><?php  echo LIT_ADDFILE_MSG ?>:&nbsp;</b></span>
					</td>
					<td align="left">
						<input type="file" name="filename" class="form-input-text"/>
					</td>
				</tr>
				<tr>
					<td align="right">
						<input type="submit" name="go_addlit" value="OK" class="form-button"/>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>