function confirm_deleting(id) {
	return confirm('Do you realy want to delete record?\nRecord id='+id);
}

function onEditRecord(isEdit) {
	if(isEdit=="yes") {
		return confirm('ATTENTION!\nA previous archive with a file for this record will be delete, or overwrite!\nDo you realy want to prolong this operation?');
	}
	else {
		return true;
	}
}
