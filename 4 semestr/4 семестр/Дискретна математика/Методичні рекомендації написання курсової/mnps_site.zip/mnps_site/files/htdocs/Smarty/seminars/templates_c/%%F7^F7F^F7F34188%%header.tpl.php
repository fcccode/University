<?php /* Smarty version 2.6.18, created on 2007-12-28 10:14:01
         compiled from header.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'popup_init', 'header.tpl', 3, false),array('function', 'popup', 'header.tpl', 85, false),)), $this); ?>

<?php echo smarty_function_popup_init(array('src' => "includes/overlib.js"), $this);?>

<?php require_once(SMARTY_CORE_DIR . 'core.smarty_include_php.php');
smarty_core_smarty_include_php(array('smarty_file' => "includes/session_check.php", 'smarty_assign' => '', 'smarty_once' => false, 'smarty_include_vars' => array()), $this); ?>


<?php 
	global $smarty;
	if(isset($_SESSION['lang'])) {
		require_once('includes/'.$_SESSION['lang'].'.lang.php');		
	}
	else {
		require_once('includes/ua.lang.php');
		
	}
	//popups assigned
	$smarty->assign('popup_orgcom_MSG',POPUP_ORGCOM_MSG);
	$smarty->assign('popup_reglament_MSG',POPUP_REGLAMENT_MSG);
	$smarty->assign('popup_viewthems_MSG',POPUP_VIEWTHEMS_MSG);
	$smarty->assign('popup_addrecord_MSG',POPUP_ADDRECORD_MSG);
	$smarty->assign('popup_foradmin_MSG',POPUP_FORADMIN_MSG);
	
 ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title><?php echo $this->_tpl_vars['title']; ?>
</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
	<LINK href="images/main.css" type=text/css rel=stylesheet>
	<script language="javascript" src="includes/checkjs.js">
	</script>
</head>
<body>
<div align="center">
<table width=960 cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td width="30%" bgcolor="#00bdcd">
			<img src="images/1.gif" width=1 height=20>
		</td>
		<td width="70%" bgcolor="#03a0b1"></td>
	</tr>
</table>
<table width=960 cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td class="backgroundlogo">
			<img src="images/1.gif" width=40 height=43>
			<span class="textLogo"><?php echo SPAN_PROJECTNAME_MSG ?></span><br>
			<img src="images/1.gif" width=40 height=17>
			<span class="textUnLogo"><?php echo SPAN_PROJECTLOGO_MSG ?><b></b></span>
		</td>
	</tr>
</table>
<table width=960 cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td bgcolor="#021d24"></td>
	</tr>
	<tr>
		<td bgcolor="#021d24"></td>
	</tr>
	<tr>
		<td bgcolor="#021d24"></td>
	</tr>
	<tr>
		<td bgcolor="#021d24"></td>
	</tr>
	<tr>
		<td bgcolor="#021d24"></td>
	</tr>
	<tr>
		<td bgcolor="#ffffff"></td>
	</tr>
	<tr>
		<td bgcolor="#ffffff"></td>
	</tr>
	<tr>
		<td bgcolor="#ffffff"></td>
	</tr>
	<tr>
		<td class="nav">			
			<img src="images/1.gif" height=30  width=40 align="middle">			
			<span class="navText"><b><a href="core.php"><?php echo HORMENU_HOME_MSG ?></a></b></span>			
			<img src="images/vline5.gif" height=30 align="middle">
			<span class="navText"><b><a href="core.php?page=orgcom" <?php echo smarty_function_popup(array('text' => $this->_tpl_vars['popup_orgcom_MSG'],'fgcolor' => "#00bdcd",'textcolor' => "#000000"), $this);?>
><?php echo HORMENU_ORGCOM_MSG ?></a></b></span>
			<img src="images/vline5.gif" height=30 align="middle">
			<span class="navText"><b><a href="core.php?page=reglament" <?php echo smarty_function_popup(array('text' => $this->_tpl_vars['popup_reglament_MSG'],'fgcolor' => "#00bdcd",'textcolor' => "#000000"), $this);?>
><?php echo HORMENU_REGLAMENT_MSG ?></a></b></span>
			<img src="images/vline5.gif" height=30 align="middle">
			<span class="navText"><b><a href="core.php?page=view" <?php echo smarty_function_popup(array('text' => $this->_tpl_vars['popup_viewthems_MSG'],'fgcolor' => "#00bdcd",'textcolor' => "#000000"), $this);?>
><?php echo HORMENU_VIEWTHEMS_MSG ?></a></b></span>
			<img src="images/vline5.gif" height=30 align="middle">
			<span class="navText"><b><a href="core.php?page=addrec" <?php echo smarty_function_popup(array('text' => $this->_tpl_vars['popup_addrecord_MSG'],'fgcolor' => "#00bdcd",'textcolor' => "#000000"), $this);?>
><?php echo HORMENU_ADDRECORD_MSG ?></a></b></span>
			<img src="images/vline5.gif" height=30 align="middle">
			<span class="navText"><b><a href="core.php?page=literature"><?php echo HORMENU_LITERATURE_MSG ?></a></b></span>
		</td>
	</tr>
</table>
<table width=960 cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td bgcolor="#f4f6f8">&nbsp;</td>
	</tr>
</table>
<table width=960 cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td class="nav1" width="130" align="left" valign="top">			
			<div class="navText" style="margin-left: 15px; text-align: left;"><b><?php echo CHOOSE_LANG_MSG ?></b></br><a href="core.php?page=langchoice&lang=en">English</a>&nbsp;|&nbsp;<a href="core.php?page=langchoice&lang=ua">���������</a><hr></div>
			<ul>
				<li>
				<span class="navText1">
				<a href="core.php"><b><?php echo HORMENU_HOME_MSG ?></b></a></span>
				<li>
				<span class="navText1">
				<a href="core.php?page=orgcom"><b><?php echo HORMENU_ORGCOM_MSG ?></b></a></span>
				<li>
				<span class="navText1">
				<a href="core.php?page=reglament"><b><?php echo HORMENU_REGLAMENT_MSG ?></b></a></span>	
				<li>
				<span class="navText1" align="left">
				<a href="core.php?page=view"><b><?php echo HORMENU_VIEWTHEMS_MSG ?></b></a></span>
				<li>
				<span class="navText1">
				<a href="core.php?page=addrec"><b><?php echo HORMENU_ADDRECORD_MSG ?></b></a></span>
				<li>
				<span class="navText1">
				<a href="core.php?page=literature"><b><?php echo HORMENU_LITERATURE_MSG ?></b></a></span>
			</ul>
			<hr>			
			<?php if ($this->_tpl_vars['islogin'] == 1): ?>
			<span class="navText1">
				<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo ADMINMENU_ADMIN_MSG ?>:</b><p/>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['user']['fname']; ?>
&nbsp;<?php echo $_SESSION['user']['lname']; ?>

				<hr>
				<br>
				&nbsp;&nbsp;<a href="core.php?page=logout"><b>Logout</b></a><br><br>				
				<ul>
					<li>					
					<span class="navText1" align="left">
					<a href="core.php?page=admin&edittype=home"><b><?php echo ADMINMENU_EDITHOME_MSG ?></b></a><p/>
					</span>
					<li>					
					<span class="navText1" align="left">
					<a href="core.php?page=admin&edittype=orgcom"><b><?php echo ADMINMENU_EDITORGCOM_MSG ?></b></a><p/>
					</span>
					<li>					
					<span class="navText1" align="left">
					<a href="core.php?page=admin&edittype=reglament"><b><?php echo ADMINMENU_REGLAMENT_MSG ?></b></a><p/>
					</span>
					<li>					
					<span class="navText1" align="left">
					<a href="core.php?page=literature_admin&lit_action=add"><b><?php echo ADMINMENU_LITERATURE_MSG ?></b></a>
					</span>
				</ul>
			</span>
			<?php else: ?>			
			<div class="navText1" style="margin-left: 10px;">
				<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="core.php?page=authorize" <?php echo smarty_function_popup(array('text' => $this->_tpl_vars['popup_foradmin_MSG'],'fgcolor' => "#00bdcd",'textcolor' => "#000000"), $this);?>
><b><?php  echo ADMINMENU_FORADMIN_MSG ?></b></a>
			</div>
			<?php endif; ?>
			<p/>
		</td>
		<td class="vline" width=30>
			<img src="images/1.gif" width=5 height=1>
		</td>
		<td class="content" width=30>
			&nbsp;
		</td>
		<td class="content" width=548 align="center">			