<?php
global $smarty,$database;
require_once(dirname(__FILE__).'/config.php');

if(isset($_SESSION['lang'])) {
	require_once(BASE_DIR.'includes/'.$_SESSION['lang'].'.lang.php');
}
else {
	require_once(BASE_DIR.'includes/ua.lang.php');		
}

$query="select * from literatures";
$result=$database->query($query);
if($result) {
	$count=$database->numRows($result);
	if($count>0) {
		for($i=0; $i<$count; $i++) {
			$row=$database->fetch($result);
			foreach($row as $key => $value) {
				$row[$key]=stripslashes($value);
			}
			$literature_array[$i]=$row;
		}
		$smarty->assign('literature_array',$literature_array);
	}
	else {
		$smarty->assign('lit_errMessage', LIT_ERR_EMPTYDB);
	}
	$smarty->display('literature.tpl');
}
?>