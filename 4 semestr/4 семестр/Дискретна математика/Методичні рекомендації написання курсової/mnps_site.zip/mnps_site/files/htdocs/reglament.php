<?php
	global $smarty,$database;
	require_once(dirname(__FILE__).'/config.php');
	
	if(isset($_SESSION['lang'])) {
		require_once(BASE_DIR.'includes/'.$_SESSION['lang'].'.lang.php');		
	}
	else {
		require_once(BASE_DIR.'includes/ua.lang.php');		
	}
	
	$query="select * from content where type='reglament' limit 1";
	$head='';
	$result=$database->query($query);
	if($result) {
		$count=$database->numRows($result);
		if($count>0) {
			$row=$database->fetch($result);
			if(empty($row['body'])) {
				$content=HOME_EMPTYCONTENT_MSG;
			}
			else {
				//Check session and choose home page
				if(isset($_SESSION['lang']) && $_SESSION['lang'] != 'ua') {
					$content=$row[$_SESSION['lang'].'_body'];
					$head=$row[$_SESSION['lang'].'_head'];
				}
				else {
					$content=$row['body'];
					$head=$row['head'];
				}
			}
		}
		else {
			$content=HOME_EMPTYCONTENT_MSG;
		}
	}
	else {
		$content=HOME_EMPTYCONTENT_MSG;
	}
	$smarty->assign('reglament_head', stripslashes($head));
	$smarty->assign('reglament_content', stripslashes($content));
	$smarty->display('reglament.tpl');
?>