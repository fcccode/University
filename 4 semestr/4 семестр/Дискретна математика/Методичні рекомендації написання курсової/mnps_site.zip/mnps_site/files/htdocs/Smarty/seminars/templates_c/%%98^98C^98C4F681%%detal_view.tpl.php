<?php /* Smarty version 2.6.18, created on 2007-12-12 22:33:32
         compiled from detal_view.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'detal_view.tpl', 24, false),)), $this); ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php 
	global $smarty;	
	if(isset($_SESSION['lang'])) {
		require_once('includes/'.$_SESSION['lang'].'.lang.php');		
	}
	else {
		require_once('includes/ua.lang.php');		
	}	
 ?>

<img src="images/1.gif" width=2 height=50>
<span class="contentText"><b><?php echo DVIEW_THEM_MSG ?>:&nbsp;</b>&quot;<?php echo $this->_tpl_vars['detal_record']['them']; ?>
&quot;</span><br>
<img src="images/1.gif"  width=2 height=30>
<table width="90%" cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td class="content">
			<span class="textError" align="center"><?php echo $this->_tpl_vars['detal_errMessage']; ?>
</span>
			<?php if ($this->_tpl_vars['detal_isError'] != 'true'): ?>
				<span class="textCopy"><b><?php echo DVIEW_PUBLICDATE_MSG ?>:</b></span>
				<span class="textCopy"><?php echo ((is_array($_tmp=$this->_tpl_vars['detal_record']['date'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d.%m.%Y") : smarty_modifier_date_format($_tmp, "%d.%m.%Y")); ?>
</span><br>
				<span class="textCopy"><b><?php echo AUTHOR_MSG ?>:</b></span>
				<span class="textCopy"><?php echo $this->_tpl_vars['detal_record']['first_name']; ?>
&nbsp;<?php echo $this->_tpl_vars['detal_record']['last_name']; ?>
</span><br>
				<span class="textCopy"><b><?php echo DVIEW_EMAIL_MSG ?>:</b></span>
				<a href="mailto:<?php echo $this->_tpl_vars['detal_record']['email']; ?>
"><?php echo $this->_tpl_vars['detal_record']['email']; ?>
</a><p/>
				<span class="textCopy"><b><?php echo DVIEW_AUTHORINFO_MSG ?>:</b></span><br>
				<span class="textCopy"><?php echo $this->_tpl_vars['detal_record']['info']; ?>
</span><p/>
				<span class="textCopy"><b><?php echo DVIEW_THEMDESCRIPT_MSG ?>:</b></span><br>
				<span class="textCopy"><?php echo $this->_tpl_vars['detal_record']['comment']; ?>
</span><p/>
				<span class="textCopy"><b><?php echo DVIEW_UPLOADFILE_MSG ?>:</b></span>
				<?php if ($this->_tpl_vars['detal_record']['filename'] == ""): ?>
				<span class="textCopy"><?php echo DVIEW_NOFILE_MSG ?></span><p/>
				<?php else: ?>
				<span class="textCopy"><a href="files/<?php echo $this->_tpl_vars['detal_record']['filename']; ?>
"><?php echo $this->_tpl_vars['detal_record']['filename']; ?>
</a></span><p/>
				<?php endif; ?>
				<p/>
				<hr>
				<div align="right"><a href="core.php?page=view">&lt;&lt; <?php echo DVIEW_BACK_MSG ?></a></div>
				<p/>
			<?php endif; ?>
		</td>
	</tr>
</table>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>