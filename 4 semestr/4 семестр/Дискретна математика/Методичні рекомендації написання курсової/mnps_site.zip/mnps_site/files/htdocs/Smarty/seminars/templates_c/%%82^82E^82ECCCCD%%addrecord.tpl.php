<?php /* Smarty version 2.6.18, created on 2007-12-12 21:21:30
         compiled from addrecord.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', 'addrecord.tpl', 27, false),array('function', 'popup', 'addrecord.tpl', 39, false),)), $this); ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php 
	global $smarty;	
	if(isset($_SESSION['lang'])) {
		require_once('includes/'.$_SESSION['lang'].'.lang.php');		
	}
	else {
		require_once('includes/ua.lang.php');		
	}
	$smarty->assign('popup_required_MSG',POPUP_REQUIRED_MSG);
	$smarty->assign('popup_required255_MSG',POPUP_REQUIRED255_MSG);
	$smarty->assign('popup_viewthems_MSG',POPUP_VIEWTHEMS_MSG);
	$smarty->assign('popup_addrecord_MSG',POPUP_ADDRECORD_MSG);
	$smarty->assign('popup_foradmin_MSG',POPUP_FORADMIN_MSG);
 ?>

<img src="images/1.gif" width=2 height=50>
<span class="contentText"><?php echo SPAN_PAGETITLE_MSG ?></span><br>
<img src="images/1.gif"  width=2 height=30>
<table width="90%" cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td class="content">
			<span class="textError" align="center"><?php echo $this->_tpl_vars['add_errMessage']; ?>
</span><br>
			<form name="addrecord" method="post" action='<?php echo ((is_array($_tmp=@$this->_tpl_vars['action'])) ? $this->_run_mod_handler('default', true, $_tmp, "core.php?page=addrec") : smarty_modifier_default($_tmp, "core.php?page=addrec")); ?>
' enctype="multipart/form-data" onSubmit="return onEditRecord('<?php echo ((is_array($_tmp=@$this->_tpl_vars['isEdit'])) ? $this->_run_mod_handler('default', true, $_tmp, 'no') : smarty_modifier_default($_tmp, 'no')); ?>
')">
			<?php 
				require_once('includes/constants.php');
				global $smarty;				
				$smarty->assign('max_file_size',MAX_FILE_SIZE);
			 ?>	
			<table border="0" width="100%">
				<tr>
					<td align="right">
						<span class="textCopy"><b><?php  echo SPAN_FNAME_MSG ?>:&nbsp;</b></span>
					</td>
					<td align="left">
						<input type="text" name="first_name" value="<?php echo $this->_tpl_vars['form_content']['first_name']; ?>
" maxlength="80" class="form-input-text" <?php echo smarty_function_popup(array('text' => $this->_tpl_vars['popup_required_MSG'],'fgcolor' => "#00bdcd",'textcolor' => "#000000"), $this);?>
/>
					</td>					
				</tr>
				<tr>
					<td align="right">
						<span class="textCopy"><b><?php  echo SPAN_LNAME_MSG ?>:&nbsp;</b></span>
					</td>
					<td align="left">
						<input type="text" name="last_name" value="<?php echo $this->_tpl_vars['form_content']['last_name']; ?>
" maxlength="80" class="form-input-text" <?php echo smarty_function_popup(array('text' => $this->_tpl_vars['popup_required_MSG'],'fgcolor' => "#00bdcd",'textcolor' => "#000000"), $this);?>
/>
					</td>
				</tr>
				<tr>
					<td align="right">
						<span class="textCopy"><b>E-mail:&nbsp;</b></span>
					</td>
					<td align="left">
						<input type="text" name="email" value="<?php echo $this->_tpl_vars['form_content']['email']; ?>
" maxlength="255" class="form-input-text" <?php echo smarty_function_popup(array('text' => $this->_tpl_vars['popup_required255_MSG'],'fgcolor' => "#00bdcd",'textcolor' => "#000000"), $this);?>
/>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<br><span class="textCopy"><b><?php echo SPAN_EXTINFO_MSG ?>:</b></span><br>
						<textarea name="info" cols="60" rows="7" class="form-input-text" wrap="virtual"/>
							<?php echo $this->_tpl_vars['form_content']['info']; ?>

						</textarea>						
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<br><span class="textCopy"><b><?php  echo SPAN_WORKNAME_MSG ?>:</b></span><br>
						<textarea name="them" cols="60" rows="7" class="form-input-text" wrap="virtual" <?php echo smarty_function_popup(array('text' => $this->_tpl_vars['popup_required255_MSG'],'fgcolor' => "#00bdcd",'textcolor' => "#000000"), $this);?>
/>
							<?php echo $this->_tpl_vars['form_content']['them']; ?>

						</textarea>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<br><span class="textCopy"><b><?php  echo SPAN_WORKDESCRIPT_MSG ?>:</b></span><br>
						<?php 
							global $smarty;
							include("includes/htmledit/fckeditor.php");
							$sBasePath = "includes/htmledit/";
							$oFCKeditor = new FCKeditor('comment');
							$oFCKeditor->BasePath	= $sBasePath;
							$oFCKeditor->Value		= $smarty->get_template_vars('comment');
							$oFCKeditor->Create();
						 ?>
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td align="right">
						<span class="textCopy"><b><?php  echo SPAN_ADDFILE_MSG ?>:&nbsp;</b></span>
					</td>
					<td align="left">
						<input type="file" name="filename" class="form-input-text" <?php echo smarty_function_popup(array('text' => ((is_array($_tmp=@$this->_tpl_vars['popup_text'])) ? $this->_run_mod_handler('default', true, $_tmp, "File must be rar, zip, tar, gzip archive<br>max file size is ".($this->_tpl_vars['max_file_size'])." bytes") : smarty_modifier_default($_tmp, "File must be rar, zip, tar, gzip archive<br>max file size is ".($this->_tpl_vars['max_file_size'])." bytes")),'fgcolor' => ((is_array($_tmp=@$this->_tpl_vars['popup_backcolor'])) ? $this->_run_mod_handler('default', true, $_tmp, "#00bdcd") : smarty_modifier_default($_tmp, "#00bdcd")),'textcolor' => ((is_array($_tmp=@$this->_tpl_vars['popup_textcolor'])) ? $this->_run_mod_handler('default', true, $_tmp, "#000000") : smarty_modifier_default($_tmp, "#000000"))), $this);?>
/>
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="go_addrecord" value="OK" class="form-button"/>
					</td>
				</tr>
			</table>
			</form>
		</td>
	</tr>
</table>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>