<?php
global $smarty,$database;
require_once(dirname(__FILE__).'/config.php');

if(isset($_SESSION['lang'])) {
	require_once(BASE_DIR.'includes/'.$_SESSION['lang'].'.lang.php');		
}
else {
	require_once(BASE_DIR.'includes/ua.lang.php');		
}

$smarty->assign('view_header', EDITING_THEMS_MSG);

if(isset($_GET['id']) && isset($_GET['page']) && $_GET['page']=="view") {
	if(!is_numeric($_GET['id'])) {
		$smarty->assign('view_errMessage',ATTACK_GETPARAM_MSG);
		$smarty->assign('view_isError', 'true');
		$smarty->display('viewlist.tpl');		
		exit;
	}
	$query="select * from users where id='".$_GET['id']."' limit 1";
	$result=$database->query($query);
	if($result) {
		$row=$database->fetch($result);
		$smarty->assign('detal_record', $row);
		$smarty->display('detal_view.tpl');
		exit;
	}
	else {
		$smarty->assign('detal_errMessage',ERR_DBACCESS_MSG);
		$smarty->assign('detal_isError', 'true');
		$smarty->display('detal_view.tpl');
		exit;
	}
}

$query="select * from users order by date desc";
$result=$database->query($query);
if($result) {
	$num_results=$database->numRows($result);
	if($num_results<=0) {
		$smarty->assign('view_errMessage',ERR_DBEMPTY_MSG);
		$smarty->assign('view_isError', 'true');
		$smarty->display('viewlist.tpl');
		exit;
	}
	
	for($i=0; $i<$num_results; $i++)
	{
		$row=$database->fetch($result);
		foreach($row as $key => $value) {
			$row[$key]=stripslashes($value);
		}
		$prep_rows[$i]=$row;
	}	
	
	$smarty->assign('prep_rows',$prep_rows);
}
else {
	$smarty->assign('view_errMessage',ERR_DBACCESS_MSG);
	$smarty->assign('view_isError', 'true');
}
$smarty->display('viewlist.tpl');
?>