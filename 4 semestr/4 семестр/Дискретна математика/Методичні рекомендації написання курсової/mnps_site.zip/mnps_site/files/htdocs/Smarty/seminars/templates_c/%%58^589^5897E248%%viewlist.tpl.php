<?php /* Smarty version 2.6.18, created on 2007-12-12 21:49:03
         compiled from viewlist.tpl */ ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php require_once(SMARTY_CORE_DIR . 'core.smarty_include_php.php');
smarty_core_smarty_include_php(array('smarty_file' => "includes/session_check.php", 'smarty_assign' => '', 'smarty_once' => false, 'smarty_include_vars' => array()), $this); ?>


<img src="images/1.gif" width=2 height=50>
<span class="contentText"><b><?php echo $this->_tpl_vars['view_header']; ?>
</b></span><br>
<img src="images/1.gif"  width=2 height=30>
<table width="90%" cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td class="content">
			<span class="textError" align="center"><?php echo $this->_tpl_vars['view_errMessage']; ?>
</span>
			<?php if ($this->_tpl_vars['view_isError'] != 'true'): ?>
				<?php if ($this->_tpl_vars['islogin'] == 1): ?>
				<table border="1" width="100%">
					<tr>
						<td class="textCopy1" align="center" width="30%"><b><?php echo AUTHOR_MSG ?></b></td>
						<td class="textCopy1" align="center" width="60%"><b><?php echo WORKNAME_MSG ?></b></td>
						<td class="textCopy1" align="center" width="10%"><b><?php echo ACTION_MSG ?></b></td>
					</tr>
				<?php $_from = $this->_tpl_vars['prep_rows']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['curr_item']):
?>
					<tr>					
						<td class="textCopy1" width="30%"><?php echo $this->_tpl_vars['curr_item']['first_name']; ?>
&nbsp;<?php echo $this->_tpl_vars['curr_item']['last_name']; ?>
</td>
						<td class="textCopy1" width="60%">
							<a href="core.php?page=view&id=<?php echo $this->_tpl_vars['curr_item']['id']; ?>
">
								&quot;<?php echo $this->_tpl_vars['curr_item']['them']; ?>
&quot;
							</a>
						</td>
						<td width="10%">
							<span class="nav1" align="left">
							<a href="core.php?page=admin&action=delete&id=<?php echo $this->_tpl_vars['curr_item']['id']; ?>
" onClick="return confirm_deleting(<?php echo $this->_tpl_vars['curr_item']['id']; ?>
)">
								<?php echo DELETE_MSG ?>
							</a><br></span>
							<span class="nav1" align="left">
							<a href="core.php?page=admin&action=edit&id=<?php echo $this->_tpl_vars['curr_item']['id']; ?>
">
								<?php echo EDIT_MSG ?>
							</a><br>
							</span>
						</td>
					</tr>
				<?php endforeach; endif; unset($_from); ?>
				</table>
				<?php else: ?>
				<table border="1" width="100%">
					<tr>
						<td class="textCopy1" align="center" width="30%"><b><?php echo AUTHOR_MSG ?></b></td>
						<td class="textCopy1" align="center" width="70%"><b><?php echo WORKNAME_MSG ?></b></td>		
					</tr>
				<?php $_from = $this->_tpl_vars['prep_rows']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['curr_item']):
?>
					<tr>					
						<td class="textCopy1" width="30%"><?php echo $this->_tpl_vars['curr_item']['first_name']; ?>
&nbsp;<?php echo $this->_tpl_vars['curr_item']['last_name']; ?>
</td>
						<td class="textCopy1" width="70%">
							<a href="core.php?page=view&id=<?php echo $this->_tpl_vars['curr_item']['id']; ?>
">
								&quot;<?php echo $this->_tpl_vars['curr_item']['them']; ?>
&quot;
							</a>
						</td>
					</tr>
				<?php endforeach; endif; unset($_from); ?>
				</table>
				<?php endif; ?>
			<?php endif; ?>
		</td>
	</tr>
</table>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>