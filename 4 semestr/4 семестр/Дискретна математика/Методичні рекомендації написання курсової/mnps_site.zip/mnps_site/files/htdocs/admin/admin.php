<?php
global $smarty,$database;
require_once(dirname(dirname(__FILE__)).'/config.php');

if(isset($_SESSION['lang'])) {
	require_once(BASE_DIR.'includes/'.$_SESSION['lang'].'.lang.php');		
}
else {
	require_once(BASE_DIR.'includes/ua.lang.php');		
}

if(!isset($_SESSION['user'])) {
	$smarty->assign('admin_errMessage',ADMINP_ACCDENY_MSG);
	$smarty->display('admin.tpl');
	exit;
}

if(isset($_GET['edittype'])) {
	
	if(!in_array($_GET['edittype'], array("home", "orgcom", "reglament", "none"))) {
		$smarty->assign('editcontent_errMessage',ATTACK_GETPARAM_MSG.'<p/>');
		$smatry->assign('isError', 'true');
		$smarty->assign('editcontent.tpl');
		exit;
	}
	switch($_GET['edittype']) {
		case "home":
			$smarty->assign('editcontent_head',ADMINP_HOMEEDITING_MSG);
			break;
			
		case "orgcom":
			$smarty->assign('editcontent_head',ADMINP_ORGCOMEDITING_MSG);
			break;
		
		case "reglament":
			$smarty->assign('editcontent_head',ADMINP_REGLAMENTEDITING_MSG);
			break;
			
		//case none - update record in DB
		case "none":
			if(!isset($_GET['editof'])) {				
				$smarty->assign('editcontent_errMessage',ADMINP_ERRGETPARAM_MSG);
				$smarty->assign('isError', 'true');
				$smarty->display('editcontent.tpl');
				exit;
			}	
			
			if(isset($_POST['go_editcontent'])) {
				if(!in_array($_GET['editof'], array("home", "orgcom", "reglament"))) {
					$smarty->assign('editcontent_errMessage',ATTACK_GETPARAM_MSG.'<br>');
					$smatry->assign('isError', 'true');
					$smarty->assign('editcontent.tpl');
					exit;
				}
				
				$save_head=$_POST['head_content'];
				$save_body=$_POST['body_content'];
				$err_msg='';
				$error_flag=false;
				
				if(!preg_match('/.{1,255}/', trim($_POST['head_content']))) {
					$err_msg.=ADMINP_ERRADDHEADER_MSG;
					$error_flag=true;
					$save_head='';
				}
				if(!preg_match('/.{0,65535}/', trim($_POST['body_content']))) {
					$err_msg.=ADMINP_ERRADDBODY_MSG;
					$error_flag=true;
					$save_body='';
				}
				
				if($error_flag) {
					switch($_GET['editof']) {
						case "home":
							$smarty->assign('editcontent_head',ADMINP_HOMEEDITING_MSG);			
						break;
			
						case "orgcom":
							$smarty->assign('editcontent_head',ADMINP_ORGCOMEDITING_MSG);
						break;
		
						case "reglament":
							$smarty->assign('editcontent_head',ADMINP_REGLAMENTEDITING_MSG);
						break;
					}
					$smarty->assign('editcontent_errMessage', $err_msg);
					$smarty->assign('head', $save_head);
					$smarty->assign('body', $save_body);
					$smarty->display('editcontent.tpl');
					exit;
				}
				
				// Check success - updating record in DB
				if(isset($_SESSION['lang']) && $_SESSION['lang'] != 'ua') {
					$query="update content set ".$_SESSION['lang']."_head='".strip_tags(addslashes(trim($_POST['head_content'])))."', ".$_SESSION['lang']."_body='".addslashes(trim($_POST['body_content']))."' where type='".$_GET['editof']."' limit 1";
				}
				else {
					$query="update content set head='".strip_tags(addslashes(trim($_POST['head_content'])))."', body='".addslashes(trim($_POST['body_content']))."' where type='".$_GET['editof']."' limit 1";
				}
				$result=$database->query($query);
				if(!$result) {
					$smarty->assign('editcontent_errMessage',ADMINP_ERRDBUPDATE_MSG);
					$smarty->assign('isError', 'true');
					$smarty->display('editcontent.tpl');
					exit;
				}
			}
			require_once('home.php');
			exit;
			
			break;
	}
	
	//Creating prefix for choose content( language) from DB
	if(isset($_SESSION['lang']) && $_SESSION['lang'] != 'ua') {
		$prefix = $_SESSION['lang']."_";
	}
	else {
		$prefix = '';
	}
	
	$query="select * from content where type='".$_GET['edittype']."' limit 1";
	$result=$database->query($query);
	if($result) {		
		$row=$database->fetch($result);
		$smarty->assign('type', $_GET['edittype']);
		$smarty->assign('head', $row[$prefix.'head']);
		$smarty->assign('body', $row[$prefix.'body']);
	}
	
	$smarty->display('editcontent.tpl');
	exit;
	
}


if(isset($_GET['action']) && isset($_GET['id'])) {
	if(!is_numeric($_GET['id'])) {
		$smarty->assign('admin_errMessage',ATTACK_GETPARAM_MSG.'<p/>');		
		$smarty->display('admin.tpl');		
		exit;
	}
	if($_GET['action']=="delete") {
		
		//Get file name from deleting record
		$query="select * from users where id='".$_GET['id']."' limit 1";
		$result=$database->query($query);
		if(!$result) {
			$smarty->assign('admin_errMessage',ADMINP_ERRDBDELETE_MSG);		
			$smarty->display('admin.tpl');
			exit;
		}
		$count=$database->numRows($result);
		$del_file_path='';
		if($count>0) {
			$row=$database->fetch($result);
			$del_file_path=$row['filename'];
		}
		
		//Deleting record
		$query="delete from  users where id='".$_GET['id']."' limit 1";
		$result=$database->query($query);
		if(!$result) {
			$smarty->assign('admin_errMessage',ADMINP_ERRDBDELETE_MSG);		
			$smarty->display('admin.tpl');
			exit;
		}		
		if(!empty($del_file_path)) {
			unlink("files/$del_file_path");
		}
		
		require_once('viewlist.php');
	}
	
	if($_GET['action']=="edit") {
		$query="select * from users where id='".$_GET['id']."' limit 1";
		$result=$database->query($query);
		if(!$result) {
			$smarty->assign('add_errMessage',ADMINP_ERRDB_MSG);
			$smarty->display('addrecord.tpl');			
			exit;
		}
		$_SESSION['edited_id']=$_GET['id'];
		$form_content=$database->fetch($result);
		$smarty->assign('action', 'core.php?page=editrec');
		$smarty->assign('form_content', $form_content);
		$smarty->assign('comment', $form_content['comment']);
		$smarty->assign('popup_text',ADMINP_ATTENTION_MSG);
		$smarty->assign('popup_backcolor', "#ffff00");
		$smarty->assign('popup_textcolor', "#ff0000");
		$smarty->assign('isEdit', "yes");
		$smarty->display('addrecord.tpl');
		exit;
	}
}
else {
	$smarty->display('admin.tpl');
}
?>