<?php /* Smarty version 2.6.18, created on 2007-12-14 18:51:53
         compiled from footer.tpl */ ?>

		</td>
		<td width="20" class="content">
			&nbsp;
		</td>
	</tr>
</table>
<table width=960 cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td bgcolor="#f4f6f8">&nbsp;</td>
	</tr>
</table>
<table width=960 cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td bgcolor="#021d24"></td>	
	</tr>
	<tr>
		<td bgcolor="#021d24"></td>
	</tr>
	<tr>
		<td bgcolor="#021d24"></td>
	</tr>
	<tr>
		<td bgcolor="#ffffff"></td>
	</tr>
</table>
<table width=960 cellspacing=0 cellpadding=0 border=0>
	<tr>
		<td bgcolor="#dfdfdf">
			<img src="images/bar.gif" width=760 height=10>
		</td>
	</tr>
</table>
<img src="images/1.gif" height=20 width=1>
<span class="textCopy" style="font-size: 10px">
Copyright 2007. <a href="mailto:ivanbuzyka@gmail.com">Ivan Buzyka</a> &amp; <a href="mailto:liliavelychko@gmail.com">Lilia Velychko</a>. All Rights Reserved.
</span>
<br>

<font style="font-family: arial; font-size: 9px; font color: black">Design by </font><font style="font-family: magneto; font-size: 10px; font color: black"><a href="http://pacificwebart.com">PacificWebArt</a></font>
</div>
</body>
</html>