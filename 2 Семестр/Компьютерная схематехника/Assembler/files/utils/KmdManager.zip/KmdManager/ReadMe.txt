
Kernel Mode Driver Manager

Intended to make testing of Kernel Mode Drivers.
Installing, Starting, Stoping and Uninstalling.

______________________
Four-F, four-f@mail.ru