/*
   Turbo Prolog 2.0 Reference Guide Chapter 3, Example Program 2
   
   Copyright (c) 1986, 88 by Borland International, Inc
   
*/
   
void hello_c_0()
{ 
   message_0("Hello from Turbo C"); 
}
